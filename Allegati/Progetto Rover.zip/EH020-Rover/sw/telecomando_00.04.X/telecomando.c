// File: telecomando.c
// Author: Mattia Bassi

////////////////////////////////////////////////////////////////////////////////
// application includes
#include "mcc_generated_files/mcc.h"
#include "telecomando.h"



////////////////////////////////////////////////////////////////////////////////
// system includes
#include <stdbool.h>
#include <string.h>  // needed by memset
#include <stdint.h>
#include <string.h>
#include <ctype.h>
#include <stdio.h>
#include <math.h>

////////////////////////////////////////////////////////////////////////////////
// constants


////////////////////////////////////////////////////////////////////////////////
// typedefs

typedef struct {   
    uint16_t tone_frequency;
    uint16_t tone_duration;
    bool     tone_is_active;
    uint32_t tone_toggle_count;
    
    uint32_t timer_reload_value;
    uint32_t tone_events_count;
    uint32_t tone_half_period_us;
} sound_t;

typedef struct {
    sound_t sound;
    
    
} telecomando_data_t;

////////////////////////////////////////////////////////////////////////////////
// macros





////////////////////////////////////////////////////////////////////////////////
// static variables
static volatile telecomando_data_t telecomando_data;



////////////////////////////////////////////////////////////////////////////////
// private functions


////////////////////////////////////////////////////////////////////////////////
// public functions

//------------------------------------------------------------------------------
uint32_t EUSART1_parseUint()
//------------------------------------------------------------------------------
{
	char c;
    uint32_t num = 0;
    
    uint16_t cycle = 0;

    // ignore non numeric char
    do {
        c = EUSART1_Read();
        cycle++;
        if (cycle >= 3) return 0;
    } while (!(c >= '0' && c <= '9'));
    
    
    do {
        num = num * 10 + c - '0';
        c = EUSART1_Read();
    }while ((c >= '0' && c <= '9'));
    
    return num;
}


//------------------------------------------------------------------------------
void EUSART1_write_str(char *str)
//------------------------------------------------------------------------------
{
	int i;
	
	// check pointers
	if (str == NULL) {
		return;
	}
	
	// write to EUSART1
	for (i = 0; i < strlen(str); i++) {
		EUSART1_Write(str[i]);
	}
}

//------------------------------------------------------------------------------
bool bluetooth_module_state()
//------------------------------------------------------------------------------
{
	return BT_STATE_PIN_GetValue();
}

//------------------------------------------------------------------------------
void tone(uint32_t frequency, uint32_t duration)
//------------------------------------------------------------------------------
{
	//   
    
        // active sound generation
        telecomando_data.sound.tone_is_active = true;

        //data.sound.tone_half_period_us = (1000000 / (frequency * 2));
        
        //data.sound.timer_reload_value = 65535 - (data.sound.tone_half_period_us / 8);
        
        telecomando_data.sound.timer_reload_value = 65536 - (31250/frequency);
        
        TMR0_WriteTimer(telecomando_data.sound.timer_reload_value);

        telecomando_data.sound.tone_toggle_count = (2 * frequency * duration) / 1000;

        //printf("rv %u, tog %u\n", data.sound.timer_reload_value, data.sound.tone_toggle_count);
        
        BUZZER_SetLow();
        TMR0_StartTimer();
        
        // wait end of sound generation
        while(telecomando_data.sound.tone_is_active == true) {
            // none, wait
        }
        BUZZER_SetLow();
    
}

//------------------------------------------------------------------------------
uint32_t get_uBat()
//------------------------------------------------------------------------------
{
    //data.battery.uBat_mv = (((5000 * adc_value * (R7_VALUE + R6_VALUE)) / (1023 * R7_VALUE)) );
    //return (uint32_t)(((5000 * adc_value * 2.446) / (1023)) );
    //return (uint32_t)(((5000*(uint32_t)ADC_GetConversion(U_BAT)*2.446)/(1023)) );
    
    uint32_t adc_value = 0;
    
    ADC_SelectChannel(U_BAT);
    ADC_StartConversion();
    while(!ADC_IsConversionDone());
    adc_value = ADC_GetConversionResult();
    
    //data.battery.uBat_v = ((5 * adc_value * (R7_VALUE + R6_VALUE)) / (1023 * R7_VALUE)) ;
    //data.battery.uBat_mv = (((5000 * adc_value * (R7_VALUE + R6_VALUE)) / (1023 * R7_VALUE)) );
    return (uint32_t)(((5000 * adc_value * 2.446) / (1023)) );
}

//------------------------------------------------------------------------------
inline uint16_t joystick1_x_read()
//------------------------------------------------------------------------------
{
    return ADC_GetConversion(JOYSTICK1_x);
}

//------------------------------------------------------------------------------
inline uint16_t joystick1_y_read()
//------------------------------------------------------------------------------
{
    return ADC_GetConversion(JOYSTICK1_y);
}

//------------------------------------------------------------------------------
inline uint16_t joystick2_x_read()
//------------------------------------------------------------------------------
{
    return ADC_GetConversion(JOYSTICK2_x);
}

//------------------------------------------------------------------------------
inline uint16_t joystick2_y_read()
//------------------------------------------------------------------------------
{
    return ADC_GetConversion(JOYSTICK2_y);
}




void tmr0_event() {
    static uint32_t events_counter = 0;
    
    //LED_2_Toggle();
     
    if (telecomando_data.sound.tone_is_active == true) {
        if (events_counter <= telecomando_data.sound.tone_toggle_count) {
            BUZZER_Toggle();
            TMR0_WriteTimer(telecomando_data.sound.timer_reload_value);
            // increment values
            events_counter++;
        } else {
            TMR0_StopTimer();
            BUZZER_SetLow();
            events_counter = 0;

            // stop sound generation
            telecomando_data.sound.tone_is_active = false;
        }
    }

}


//------------------------------------------------------------------------------
inline void tone_init()
//------------------------------------------------------------------------------
{
    // stop timer0
    TMR0_StopTimer();
    // reload timer0
    TMR0_Reload();
    
    TMR0_SetInterruptHandler(tmr0_event);
    
    BUZZER_SetLow();
}