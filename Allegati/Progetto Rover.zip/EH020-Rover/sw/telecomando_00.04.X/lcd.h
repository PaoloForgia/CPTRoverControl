#include <xc.h>
#include <stdint.h>
#include <stdbool.h>
#include <stdio.h>

// define LCD lines connected to MCU's pins (can be used any pins)

// LCD line RW connected to Vss (ground)

// LCD line RS connected to RD5 pin
#define RS_PIN  TRISDbits.TRISD5 = 0
#define RS_H    LATDbits.LD5 = 1
#define RS_L    LATDbits.LD5 = 0

// LCD line E connected to RD4 pin
#define EN_PIN  TRISDbits.TRISD4 = 0
#define EN_H    LATDbits.LD4 = 1
#define EN_L    LATDbits.LD4 = 0

// LCD data bus (4-bit interface)
// data line 4..7 connected to RD0..RD3 pins
#define D4_PIN  TRISDbits.TRISD0 = 0
#define D4_H    LATDbits.LD0 = 1
#define D4_L    LATDbits.LD0 = 0

#define D5_PIN  TRISDbits.TRISD1 = 0
#define D5_H    LATDbits.LD1 = 1
#define D5_L    LATDbits.LD1 = 0

#define D6_PIN  TRISDbits.TRISD2 = 0
#define D6_H    LATDbits.LD2 = 1
#define D6_L    LATDbits.LD2 = 0

#define D7_PIN  TRISDbits.TRISD3=0
#define D7_H    LATDbits.LD3=1
#define D7_L    LATDbits.LD3=0

// LCD backlight line connected to RD5 pin
//#define BL_PIN  TRISD5=0
//#define BL_ON   RD5=1
//#define BL_OFF  RD5=0


void lcd_init(void);
void lcd_write(uint8_t data);
void lcd_cmd(uint8_t data);
void lcd_clear(void);
void lcd_goto(uint8_t line, uint8_t column);
void lcd_char(uint8_t sign);
void lcd_print(const char *str);
void lcd_right(void);
void lcd_left(void);


///////////////////////////////////////////////////////////////////////////////
void lcd_init(void)
{
//init MCU pins (set as output)
RS_PIN;
EN_PIN;
D4_PIN;
D5_PIN;
D6_PIN;
D7_PIN;
//BL_PIN;

//init LCD controller
__delay_ms(20); //delay on power up
lcd_cmd(0b0011);
__delay_ms(5); //wait for the instruction to complete
lcd_cmd(0b0011);
__delay_us(200); //wait for the instruction to complete
lcd_cmd(0b0011);
__delay_us(200);
lcd_cmd(0b0010); //enable 4-bit mode
__delay_us(50);
lcd_cmd(0b0010);
lcd_cmd(0b1000); //4-bit mode, 2-line, 5x8 font
__delay_us(50);
lcd_cmd(0b0000);
lcd_cmd(0b1000); //display off
__delay_us(50);
lcd_clear();
lcd_cmd(0b0000);
lcd_cmd(0b0110); //entry mode set
__delay_us(50);
lcd_cmd(0b0000);
lcd_cmd(0b1100); //display on, cursor off, blink off
__delay_us(50);
}


///////////////////////////////////////////////////////////////////////////////
void lcd_write(uint8_t data) //write data to LCD
{
if(data & 1) D4_H;
else D4_L;
	
if(data & 2) D5_H;
else D5_L;
	
if(data & 4) D6_H;
else D6_L;
	
if(data & 8) D7_H;
else D7_L;

EN_H;
__delay_us(50);
EN_L;
}


///////////////////////////////////////////////////////////////////////////////
void lcd_cmd(uint8_t data) //send command to LCD
{ 
RS_L;
lcd_write(data);
}


///////////////////////////////////////////////////////////////////////////////
void lcd_clear(void) //clear screen
{
lcd_cmd(0b0000);
lcd_cmd(0b0001);
__delay_ms(5);
}


///////////////////////////////////////////////////////////////////////////////
void lcd_goto(uint8_t line, uint8_t column) //line 0..1, column 0..39
{
lcd_cmd(((0x80+(line<<6))+column)>>4);
lcd_cmd((0x80+(line<<6))+column);
}


///////////////////////////////////////////////////////////////////////////////
void lcd_char(uint8_t sign) //print a character
{
RS_H;
lcd_write(sign>>4);
lcd_write(sign);
}


///////////////////////////////////////////////////////////////////////////////
void lcd_print(const char *str) //print a string
{
while(*str) lcd_char(*str++);
}


///////////////////////////////////////////////////////////////////////////////
void lcd_right(void) //shift right display 
{
lcd_cmd(0x01);
lcd_cmd(0x0C);
}


///////////////////////////////////////////////////////////////////////////////
void lcd_left(void) //shift left display
{
lcd_cmd(0x01);
lcd_cmd(0x08);
}



///////////////////////////////////////////////////////////////////////////////
// my additional function
void lcd_print_number(uint32_t num)
{
	uint8_t i = 0;
    char str[10];
    
    snprintf(str, 10, "%u\0", num);
//    while (num != 0) 
//    { 
//        int rem = num % 10; 
//        str[i++] = (rem > 9)? (rem-10) + 'a' : rem + '0'; 
//        num = num/10; 
//    } 
//    str[i] = '\0';
    
	for(i=0; str[i] != '\0'; i++) {
	   lcd_char(str[i]);
    }
}
///////////////////////////////////////////////////////////////////////////////
// my additional function
void CreateCustomCharacter (uint8_t *pattern, uint8_t location)
{ 
    uint8_t i=0; 
    //lcd_cmd(0x40+(location*8));     //Send the Address of CGRAM
    lcd_cmd(0x40+(location*8));
    lcd_cmd(0x00);
    
    
    for (i=0; i<8; i++) {
        lcd_char(pattern[i]);         //Pass the bytes of pattern on LCD 

    }
    //lcd_cmd(0x00);
////        __delay_ms(1);
//        lcd_cmd(0x00);
//        lcd_cmd(0x02);
}







///* Microchip Technology Inc. and its subsidiaries.  You may use this software 
// * and any derivatives exclusively with Microchip products. 
// * 
// * THIS SOFTWARE IS SUPPLIED BY MICROCHIP "AS IS".  NO WARRANTIES, WHETHER 
// * EXPRESS, IMPLIED OR STATUTORY, APPLY TO THIS SOFTWARE, INCLUDING ANY IMPLIED 
// * WARRANTIES OF NON-INFRINGEMENT, MERCHANTABILITY, AND FITNESS FOR A 
// * PARTICULAR PURPOSE, OR ITS INTERACTION WITH MICROCHIP PRODUCTS, COMBINATION 
// * WITH ANY OTHER PRODUCTS, OR USE IN ANY APPLICATION. 
// *
// * IN NO EVENT WILL MICROCHIP BE LIABLE FOR ANY INDIRECT, SPECIAL, PUNITIVE, 
// * INCIDENTAL OR CONSEQUENTIAL LOSS, DAMAGE, COST OR EXPENSE OF ANY KIND 
// * WHATSOEVER RELATED TO THE SOFTWARE, HOWEVER CAUSED, EVEN IF MICROCHIP HAS 
// * BEEN ADVISED OF THE POSSIBILITY OR THE DAMAGES ARE FORESEEABLE.  TO THE 
// * FULLEST EXTENT ALLOWED BY LAW, MICROCHIP'S TOTAL LIABILITY ON ALL CLAIMS 
// * IN ANY WAY RELATED TO THIS SOFTWARE WILL NOT EXCEED THE AMOUNT OF FEES, IF 
// * ANY, THAT YOU HAVE PAID DIRECTLY TO MICROCHIP FOR THIS SOFTWARE.
// *
// * MICROCHIP PROVIDES THIS SOFTWARE CONDITIONALLY UPON YOUR ACCEPTANCE OF THESE 
// * TERMS. 
// */
//
///* 
// * File:   
// * Author: 
// * Comments:
// * Revision history: 
// */
//
//// This is a guard condition so that contents of this file are not included
//// more than once.  
//#ifndef XC_HEADER_TEMPLATE_H
//#define	XC_HEADER_TEMPLATE_H
//
//
//
//#include <xc.h> // include processor files - each processor file is guarded.  
//#include <string.h>
////LCD Functions Developed by electroSome
//#define RS LCD_RS_PORT
//#define EN LCD_E_PORT
//#define D4 LCD_DB4_PORT
//#define D5 LCD_DB5_PORT
//#define D6 LCD_DB6_PORT
//#define D7 LCD_DB7_PORT
//
//void Lcd_Port(char a)
//{
//	if(a & 1)
//		D4 = 1;
//	else
//		D4 = 0;
//
//	if(a & 2)
//		D5 = 1;
//	else
//		D5 = 0;
//
//	if(a & 4)
//		D6 = 1;
//	else
//		D6 = 0;
//
//	if(a & 8)
//		D7 = 1;
//	else
//		D7 = 0;
//}
//void Lcd_Cmd(char a)
//{
//	RS = 0;             // => RS = 0
//	Lcd_Port(a);
//	EN  = 1;             // => E = 1
//    __delay_ms(1);
//    EN  = 0;             // => E = 0
//}
//
//Lcd_Clear()
//{
//	Lcd_Cmd(0);
//	Lcd_Cmd(1);
//}
//
//void Lcd_Set_Cursor(char a, char b)
//{
//	char temp,z,y;
//	if(a == 1)
//	{
//	  temp = 0x80 + b - 1;
//		z = temp>>4;
//		y = temp & 0x0F;
//		Lcd_Cmd(z);
//		Lcd_Cmd(y);
//	}
//	else if(a == 2)
//	{
//		temp = 0xC0 + b - 1;
//		z = temp>>4;
//		y = temp & 0x0F;
//		Lcd_Cmd(z);
//		Lcd_Cmd(y);
//	}
//}
//
//void Lcd_Init()
//{
//  Lcd_Port(0x00);
//   __delay_ms(20);
//  Lcd_Cmd(0x03);
//	__delay_ms(5);
//  Lcd_Cmd(0x03);
//	__delay_ms(11);
//  Lcd_Cmd(0x03);
//  /////////////////////////////////////////////////////
//  Lcd_Cmd(0x02);
//  Lcd_Cmd(0x02);
//  Lcd_Cmd(0x08);
//  Lcd_Cmd(0x00);
//  Lcd_Cmd(0x0C);
//  Lcd_Cmd(0x00);
//  Lcd_Cmd(0x06);
//}
//
//void Lcd_Write_Char(char a)
//{
//   char temp,y;
//   temp = a&0x0F;
//   y = a&0xF0;
//   RS = 1;             // => RS = 1
//   Lcd_Port(y>>4);             //Data transfer
//   EN = 1;
//   //__delay_us(40);
//   //__delay_us(5);
//   EN = 0;
//   Lcd_Port(temp);
//   EN = 1;
//   //__delay_us(40);
//   //__delay_us(5);
//   EN = 0;
//}
//
//void Lcd_Write_String(char *a)
//{
//	int i;
//	for(i=0;a[i]!='\0';i++)
//	   Lcd_Write_Char(a[i]);
//}
//
//// my function
//void Lcd_Write_Number(uint32_t num)
//{
//	int i = 0;
//    char str[10];
//    
//    snprintf(str, 10, "%u\0", num);
////    while (num != 0) 
////    { 
////        int rem = num % 10; 
////        str[i++] = (rem > 9)? (rem-10) + 'a' : rem + '0'; 
////        num = num/10; 
////    } 
////    str[i] = '\0';
//    
//	for(i=0; str[i] != '\0'; i++) {
//	   Lcd_Write_Char(str[i]);
//    }
//}
//
//void Lcd_Shift_Right()
//{
//	Lcd_Cmd(0x01);
//	Lcd_Cmd(0x0C);
//}
//
//void Lcd_Shift_Left()
//{
//	Lcd_Cmd(0x01);
//	Lcd_Cmd(0x08);
//}
//
//
//
//#endif	/* XC_HEADER_TEMPLATE_H */

