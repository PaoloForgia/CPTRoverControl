// File: main.c
// Author: Mattia Bassi 
// Description: last program for telecomando_v1

/**
  Generated Main Source File

  Company:
    Microchip Technology Inc.

  File Name:
    main.c

  Summary:
    This is the main file generated using PIC10 / PIC12 / PIC16 / PIC18 MCUs

  Description:
    This header file provides implementations for driver APIs for all modules selected in the GUI.
    Generation Information :
        Product Revision  :  PIC10 / PIC12 / PIC16 / PIC18 MCUs - 1.81.5
        Device            :  PIC18F45K22
        Driver Version    :  2.00
*/

/*
    (c) 2018 Microchip Technology Inc. and its subsidiaries. 
    
    Subject to your compliance with these terms, you may use Microchip software and any 
    derivatives exclusively with Microchip products. It is your responsibility to comply with third party 
    license terms applicable to your use of third party software (including open source software) that 
    may accompany Microchip software.
    
    THIS SOFTWARE IS SUPPLIED BY MICROCHIP "AS IS". NO WARRANTIES, WHETHER 
    EXPRESS, IMPLIED OR STATUTORY, APPLY TO THIS SOFTWARE, INCLUDING ANY 
    IMPLIED WARRANTIES OF NON-INFRINGEMENT, MERCHANTABILITY, AND FITNESS 
    FOR A PARTICULAR PURPOSE.
    
    IN NO EVENT WILL MICROCHIP BE LIABLE FOR ANY INDIRECT, SPECIAL, PUNITIVE, 
    INCIDENTAL OR CONSEQUENTIAL LOSS, DAMAGE, COST OR EXPENSE OF ANY KIND 
    WHATSOEVER RELATED TO THE SOFTWARE, HOWEVER CAUSED, EVEN IF MICROCHIP 
    HAS BEEN ADVISED OF THE POSSIBILITY OR THE DAMAGES ARE FORESEEABLE. TO 
    THE FULLEST EXTENT ALLOWED BY LAW, MICROCHIP'S TOTAL LIABILITY ON ALL 
    CLAIMS IN ANY WAY RELATED TO THIS SOFTWARE WILL NOT EXCEED THE AMOUNT 
    OF FEES, IF ANY, THAT YOU HAVE PAID DIRECTLY TO MICROCHIP FOR THIS 
    SOFTWARE.
*/

////////////////////////////////////////////////////////////////////////////////
// application includes
#include "mcc_generated_files/mcc.h"
#include "lcd.h"
#include "telecomando.h"

////////////////////////////////////////////////////////////////////////////////
// system includes
#include <string.h>
#include <ctype.h>
#include <stdio.h>
#include <math.h>


////////////////////////////////////////////////////////////////////////////////
// constants
#define UBAT_TELEC_MAX_MV 9000 // mV
#define UBAT_TELEC_TH_MV  7200 // mV
#define UBAT_TELEC_MIN_MV 5000 // mV

#define UBAT_ROVER_MAX_MV 9000 // mV
#define UBAT_ROVER_TH_MV  7200 // mV
#define UBAT_ROVER_MIN_MV 5000 // mV

#define JOYSTICK_VALUE_THR 10 // 50
#define JOYSTICKS_SAMPLES  10 // number of sample used for the average
#define JOYSTICK_DEFAULT_VALUE 500

#define UBAT_SAMPLES 4 // number of sample used for the average
////////////////////////////////////////////////////////////////////////////////
// typedefs


typedef enum {   
    SCREEN_POWER_ON,
    SCREEN_CONNECTION_LOST,
    SCREEN_CONNECTED, 
    SCREEN_WAIT_CONNECTION,       
    SCREEN_DISTANCE,
    SCREEN_OBSTACLE,
    SCREEN_EMERGENCY_STOP,
    SCREEN_CLEAR,
    SCREEN_BATTERY,
    SCREEN_TEL_BAT_LOW,
    SCREEN_ROV_BAT_LOW,
            
    // reserved value
	SCREEN_MAX
} display_screen_e;

typedef struct {   
    uint16_t J1x;
    uint16_t J1y;
    uint16_t J2x;
    uint16_t J2y;
    
    uint16_t J1x_prec;
    uint16_t J1y_prec;
    uint16_t J2x_prec;
    uint16_t J2y_prec;
    
    uint32_t J1y_values[JOYSTICKS_SAMPLES];
    uint32_t J2y_values[JOYSTICKS_SAMPLES];
    
    uint16_t J1y_average;
    uint16_t J2y_average;
        
} joystick_t;



typedef struct {   
    uint32_t uBat_mv;
    uint32_t uBat_percent;
    bool uBat_is_checked;
    
    uint32_t uBat_values[UBAT_SAMPLES];
} battery_t;

typedef struct {   
    uint16_t speed;
    uint16_t distance;
    
    uint32_t uBat_mv;
    uint32_t uBat_percent;
} rover_value_t;

typedef struct {   
    bool prec_state;
    
} bt_module_t;

typedef struct {
    joystick_t joystick;
    battery_t battery;
    rover_value_t rover_value;
    bt_module_t bt_module;
    
    display_screen_e current_screen;
    bool refresh_display;
    bool lights;
    
} data_t;

////////////////////////////////////////////////////////////////////////////////
// static variables
static volatile data_t data;

////////////////////////////////////////////////////////////////////////////////
// private functions

//------------------------------------------------------------------------------
void leds_blink()
//------------------------------------------------------------------------------
{
    // LEDs blink
    LED1_SetHigh();
    LED2_SetHigh();
    LED3_SetHigh();
    LED4_SetHigh();
    __delay_ms(500);
    LED1_SetLow();
    LED2_SetLow();
    LED3_SetLow();
    LED4_SetLow();
    __delay_ms(500);
}


//------------------------------------------------------------------------------
void lcd_display(display_screen_e screen)
//------------------------------------------------------------------------------
{
    
    switch (screen) {
        case SCREEN_POWER_ON: {
            lcd_clear();
            lcd_goto(0,4);
            lcd_print("Rover v1");
             __delay_ms(1000);
            lcd_clear();
            lcd_goto(0,2);
            lcd_print("Developed By");
            lcd_goto(1,0);
            lcd_print("Mattia Bassi 4E");            
            __delay_ms(500);
            lcd_clear();    
            break;
        }
        case SCREEN_DISTANCE: {
            lcd_goto(0,0);
            lcd_print("    DISTANCE    ");
            lcd_goto(1,0);
            lcd_print("d = ");

            lcd_print_number(data.rover_value.distance);
            lcd_print(" cm      ");
            break;
        }
        
        case SCREEN_BATTERY: {
            lcd_goto(0,0);
            lcd_print("Bat TEL: ");
            lcd_print_number(data.battery.uBat_percent);
            lcd_print("%      ");
            lcd_goto(1,0);
            lcd_print("Bat ROV: ");
            lcd_print_number(data.rover_value.uBat_percent);
            lcd_print("%      ");
            break;
        }
        
        case SCREEN_ROV_BAT_LOW: {
            lcd_goto(0,0);
            lcd_print(" Bat ROVER  LOW ");
            lcd_goto(1,0);
            lcd_print(" BATTERY: ");
            lcd_print_number(data.rover_value.uBat_percent);
            lcd_print("%    ");
            break;
        }
        
        case SCREEN_TEL_BAT_LOW: {
            lcd_goto(0,0);
            lcd_print(" Bat TELEC. LOW ");
            lcd_goto(1,0);
            lcd_print(" BATTERY: ");
            lcd_print_number(data.battery.uBat_percent);
            lcd_print("%    ");
            break;
        }
        
        case SCREEN_OBSTACLE: {
            lcd_goto(0,0);
            lcd_print(">>> OBSTACLE <<<");
            lcd_goto(1,0);
            lcd_print(">>> DETECTED <<<");
            break;
        }
        
        case SCREEN_CONNECTED: {
            lcd_clear();
            lcd_goto(0,3);
            lcd_print("Connected!");
            break;
        }
        
        case SCREEN_WAIT_CONNECTION: {
            lcd_clear();
            lcd_goto(0,0);
            lcd_print("  Connection... ");
            break;
        }
        
        case SCREEN_CONNECTION_LOST: {
            lcd_clear();
            lcd_goto(0,0);
            lcd_print("CONNECTION LOST!");
            break;
        }
        
        
        case SCREEN_EMERGENCY_STOP: {
            lcd_goto(0,0);
            lcd_print("   EMERGENCY    ");
            lcd_goto(1,0);
            lcd_print("      STOP      ");
            break;
        }
        
        default: {
            // not valid screen to display
            break;
        }
    }
    
}

//------------------------------------------------------------------------------
void manage_rover_data()
//------------------------------------------------------------------------------
{
    static uint16_t c = 0;
    
    // read data from remote control
    if (EUSART1_is_rx_ready() == true) {
            c = EUSART1_Read();
            
            switch (c) {
                case 'd': {
                    data.rover_value.distance = EUSART1_parseUint();
                    LED3_Toggle();
                    break;
                }
                                
                case 'b': {
                    data.rover_value.uBat_mv = EUSART1_parseUint();
                    data.rover_value.uBat_percent = ((data.rover_value.uBat_mv - UBAT_ROVER_MIN_MV)*100) / (UBAT_ROVER_MAX_MV - UBAT_ROVER_MIN_MV);
                    
                    if (data.rover_value.uBat_percent > 100) {
                        data.rover_value.uBat_percent = 100;
                    }
                    
                    // rover battery check
                    if (data.rover_value.uBat_mv <= UBAT_ROVER_TH_MV) {
                        // low rover battery
                        lcd_display(SCREEN_ROV_BAT_LOW);
                        LED1_SetHigh();
                        LED2_SetHigh();
                        LED3_SetHigh();
                        LED4_SetHigh();
                        __delay_ms(2000);
                        lcd_clear();
                        LED1_SetLow();
                        LED2_SetLow();
                        LED3_SetLow();
                        LED4_SetLow();
                    }
                    
                    LED1_Toggle();
                    break;
                }
                               
                case 'O': {
                    // obstacle detected
                    lcd_display(SCREEN_OBSTACLE);
                    // LEDs blink
                    LED1_SetHigh();
                    LED2_SetHigh();
                    LED3_SetHigh();
                    LED4_SetHigh();
                    DELAY_milliseconds(500);
                    LED1_SetLow();
                    LED2_SetLow();
                    LED3_SetLow();
                    LED4_SetLow();
                    lcd_clear();
                    
                    break;
                }
                
                default: {
                    // none, invalid command
                    break;
                }
            }
        }
}


//------------------------------------------------------------------------------
void add_uBat_sample(uint32_t value)
//------------------------------------------------------------------------------
{
    static uint16_t sample_index = 0;
    
    // store current value
    if (sample_index < UBAT_SAMPLES) {
        data.battery.uBat_values[sample_index++] = value;
    } else {
        sample_index = 0;
    }
}


//------------------------------------------------------------------------------
void update_uBat_average()
//------------------------------------------------------------------------------
{
    uint32_t average = 0;
	uint8_t i;
    
    // execute average calculation
	average = 0;
	for (i = 0; i < UBAT_SAMPLES; i++) {
		average += data.battery.uBat_values[i];
	}
	average /= UBAT_SAMPLES;
    
    data.battery.uBat_mv = average;
}




//------------------------------------------------------------------------------
void add_joysticks_sample(uint32_t value_y1, uint32_t value_y2)
//------------------------------------------------------------------------------
{
    static uint16_t sample_index = 0;
    
    // store current value
    if (sample_index < JOYSTICKS_SAMPLES) {
        data.joystick.J1y_values[sample_index] = value_y1;
        data.joystick.J2y_values[sample_index] = value_y2;
        sample_index++;
    } else {
        sample_index = 0;
    }
}


//------------------------------------------------------------------------------
void update_joysticks_average()
//------------------------------------------------------------------------------
{
    uint32_t average1 = 0;
    uint32_t average2 = 0;
	uint8_t i;
    
    // execute average calculation
	
    
	for (i = 0; i < JOYSTICKS_SAMPLES; i++) {
		average1 += data.joystick.J1y_values[i];
        average2 += data.joystick.J2y_values[i];
	}
	data.joystick.J1y_average = (average1 /= JOYSTICKS_SAMPLES);
    data.joystick.J2y_average = (average2 /= JOYSTICKS_SAMPLES);
    
}

//uint8_t Pattern1[8] = { 0x00, 0x00, 0x0A, 0x1F, 0x1F, 0x0E, 0x04, 0x00};

void tmr1_event();
void tmr3_event();

/*
                         Main application
 */
void main(void)
{
    // Initialize the device
    SYSTEM_Initialize();

    // If using interrupts in PIC18 High/Low Priority Mode you need to enable the Global High and Low Interrupts
    // If using interrupts in PIC Mid-Range Compatibility Mode you need to enable the Global and Peripheral Interrupts
    // Use the following macros to:

    // Enable the Global Interrupts
    INTERRUPT_GlobalInterruptEnable();

    // Disable the Global Interrupts
    //INTERRUPT_GlobalInterruptDisable();

    // Enable the Peripheral Interrupts
    INTERRUPT_PeripheralInterruptEnable();

    // Disable the Peripheral Interrupts
    //INTERRUPT_PeripheralInterruptDisable();
    
    // init cache
	memset((void *)&data, 0, sizeof(data_t));
    
    uint16_t i;
    
    // tone init
    tone_init();
    // LCD init
    lcd_init();
    
    
    // set interrupts handlers and start timers
    TMR1_SetInterruptHandler(tmr1_event);
    TMR1_StartTimer();
    TMR3_SetInterruptHandler(tmr3_event);
    TMR3_StartTimer();
    
    
    // init uBat samples array
    for (i = 0; i < UBAT_SAMPLES; i++) {
        add_uBat_sample(get_uBat());
    }
    // refresh telecomando battery value
    update_uBat_average();
    
    
    // init joystiks samples array
    for (i = 0; i < JOYSTICKS_SAMPLES; i++) {
        add_joysticks_sample(JOYSTICK_DEFAULT_VALUE, JOYSTICK_DEFAULT_VALUE);
    }
    // refresh telecomando battery value
    update_joysticks_average();
    
    leds_blink();
    
    data.bt_module.prec_state = bluetooth_module_state();
    
    data.joystick.J1x_prec = 0;
    data.joystick.J1y_prec = 0;
    data.joystick.J2x_prec = 0;
    data.joystick.J2y_prec = 0;
    
    data.battery.uBat_is_checked = false;
    
    // init rover battery values with default values
    data.rover_value.uBat_mv = 9000;
    data.rover_value.uBat_percent = 100;
    
    // first battery tension check
    data.battery.uBat_mv = get_uBat();    
    data.battery.uBat_percent = ((data.battery.uBat_mv - UBAT_TELEC_MIN_MV) * 100) / (UBAT_TELEC_MAX_MV - UBAT_TELEC_MIN_MV);
    if (data.battery.uBat_percent > 100) data.battery.uBat_percent = 100;
    data.battery.uBat_is_checked = true;
    
    // request to rover a refresh of distance and battery current value 
    EUSART1_Write('R');
    
    lcd_display(SCREEN_POWER_ON);
    
    // check bluetooth connection and display connection state
    if (bluetooth_module_state() == BT_MODULE_NOT_CONNECTED) {
        lcd_display(SCREEN_WAIT_CONNECTION);
        while (bluetooth_module_state() == BT_MODULE_NOT_CONNECTED) {
            // wait connection
        }   
    }
    data.bt_module.prec_state = BT_MODULE_CONNECTED;
    
    
    lcd_display(SCREEN_CONNECTED);
    __delay_ms(1000);
    
    
    // show battery value
//    lcd_display(SCREEN_BATTERY);
//    __delay_ms(2000);
//    lcd_clear();
    
    //data.current_screen = SCREEN_DISTANCE;
    data.current_screen = SCREEN_BATTERY;
    

    while (true)
    {
        // manage data sended by rover
        manage_rover_data();
        
        // check connection with rover
        if (bluetooth_module_state() == BT_MODULE_NOT_CONNECTED && data.bt_module.prec_state == BT_MODULE_CONNECTED) {
            // disconnected
            lcd_display(SCREEN_CONNECTION_LOST);
            __delay_ms(1000);
            lcd_display(SCREEN_WAIT_CONNECTION);
            data.current_screen = SCREEN_WAIT_CONNECTION;
            data.bt_module.prec_state = BT_MODULE_NOT_CONNECTED;
        }
        
        if (bluetooth_module_state() == BT_MODULE_CONNECTED && data.bt_module.prec_state == BT_MODULE_NOT_CONNECTED) {
            // reconnected
            lcd_display(SCREEN_CONNECTED);
            // request to rovera a refresh of distance and battery current value 
            EUSART1_Write('R');
            __delay_ms(1000);
            data.bt_module.prec_state = BT_MODULE_CONNECTED;
        }
        
        
        // telecomando battery check
        if (data.battery.uBat_mv < UBAT_TELEC_TH_MV && data.battery.uBat_is_checked == true) {
            // low telecomando battery
            lcd_clear();
            lcd_display(SCREEN_TEL_BAT_LOW);
            LED1_SetHigh();
            LED2_SetHigh();
            LED3_SetHigh();
            LED4_SetHigh();
            __delay_ms(2000);
            lcd_clear();
            LED1_SetLow();
            LED2_SetLow();
            LED3_SetLow();
            LED4_SetLow();
            data.battery.uBat_is_checked = false;
        }

                
        // read joysticks values
        //data.joystick.J1x = joystick1_x_read();
        data.joystick.J1y = joystick1_y_read();
        //data.joystick.J2x = joystick2_x_read();
        data.joystick.J2y = joystick2_y_read();
        
        add_joysticks_sample(data.joystick.J1y, data.joystick.J2y);
        update_joysticks_average();
        
        // send joystick values to rover if values are changed
//        if (abs(data.joystick.J1x - data.joystick.J1x_prec) > JOYSTICK_VALUE_THR) {
//            printf("X%u\n", data.joystick.J1x);
//            data.joystick.J1x_prec = data.joystick.J1x;
//        }
        
        if (abs(data.joystick.J1y_average - data.joystick.J1y_prec) > JOYSTICK_VALUE_THR) {//if (abs(data.joystick.J1y - data.joystick.J1y_prec) > JOYSTICK_VALUE_THR) {
            printf("Y%u\n", data.joystick.J1y_average);
            data.joystick.J1y_prec = data.joystick.J1y_average;//data.joystick.J1y_prec = data.joystick.J1y;
        }
        
//        if (abs(data.joystick.J2x - data.joystick.J2x_prec) > JOYSTICK_VALUE_THR) {
//            printf("x%u\n", data.joystick.J2x);
//            data.joystick.J2x_prec = data.joystick.J2x;
//        }
        
        if (abs(data.joystick.J2y_average - data.joystick.J2y_prec) > JOYSTICK_VALUE_THR) {//if (abs(data.joystick.J2y - data.joystick.J2y_prec) > JOYSTICK_VALUE_THR) {
            printf("y%u\n", data.joystick.J2y_average);
            data.joystick.J2y_prec = data.joystick.J2y_average;//data.joystick.J2y_prec = data.joystick.J2y;
        }
        
        // debug value print
        //printf("J1x %4u, J1y %4u, J2x %4u, J2y %4u \n", data.joystick.J1x, data.joystick.J1y, data.joystick.J2x, data.joystick.J2y);
        
        // manage switches
        if (SW1_GetValue() == SW_PRESSED) {
            // toggle lights of the rover
            //printf("L");
            EUSART1_Write('L');
            __delay_ms(200);
        }
        
        if (SW2_GetValue() == SW_PRESSED) {
            // clacson, do an acoustic signal with buzzer
            //printf("C");
            EUSART1_Write('C');
            __delay_ms(200);
        }
        
        if (SW3_GetValue() == SW_PRESSED) {
            // emergency STOP
            //printf("S");
            EUSART1_Write('S');
            lcd_display(SCREEN_EMERGENCY_STOP);
            __delay_ms(1000);
            lcd_clear();
        }
        
        if (SW4_GetValue() == SW_PRESSED) {
            // change information showed on the lcd
            
            //printf("A");
            //EUSART1_Write('A');
            
            switch (data.current_screen) {
                case SCREEN_DISTANCE: {
                    data.current_screen = SCREEN_BATTERY;
                    break;
                }
                
                case SCREEN_BATTERY: {
                    data.current_screen = SCREEN_DISTANCE;
                    break;
                }
                
                default: {
                    data.current_screen = SCREEN_DISTANCE;
                    break;
                }
            }
            
            while(SW4_GetValue() == SW_PRESSED);
        }
        
//        if (SW_JOY_P1_GetValue() == SW_PRESSED) {
//            // none
//        } 
//        
//        if (SW_JOY_P2_GetValue() == SW_PRESSED) {
//            // none
//        } 
        
        
        // refresh display only every 2s
        if (data.refresh_display == true) {
            lcd_display(data.current_screen);
            data.refresh_display = false;
        }
        
        LED4_Toggle();
    }
}

//------------------------------------------------------------------------------
void tmr3_event()
//------------------------------------------------------------------------------
{
    // 250 ms event
    //lcd_display(data.current_screen);
    data.refresh_display = true;
}

//------------------------------------------------------------------------------
void tmr1_event()
//------------------------------------------------------------------------------
{
    // 8 s event
    LED2_Toggle();
    
//    data.battery.uBat_mv = get_uBat();
//    data.battery.uBat_percent = ((data.battery.uBat_mv - UBAT_MIN_MV)*100)/(UBAT_MAX_MV - UBAT_MIN_MV);
//    if (data.battery.uBat_percent > 100) data.battery.uBat_percent = 100;
//    data.battery.uBat_is_checked = true;
    
    // add new sample value
    add_uBat_sample(get_uBat());
    // calculate average and refresh telecomando uBat_mv value
    update_uBat_average();
    
    data.battery.uBat_percent = ((data.battery.uBat_mv - UBAT_TELEC_MIN_MV)*100)/(UBAT_TELEC_MAX_MV - UBAT_TELEC_MIN_MV);
    // constrain in the range 0-100%
    if (data.battery.uBat_percent > 100) data.battery.uBat_percent = 100;
    data.battery.uBat_is_checked = true;
}

/**
 End of File
*/