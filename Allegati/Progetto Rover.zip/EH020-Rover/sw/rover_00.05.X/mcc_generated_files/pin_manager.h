/**
  @Generated Pin Manager Header File

  @Company:
    Microchip Technology Inc.

  @File Name:
    pin_manager.h

  @Summary:
    This is the Pin Manager file generated using PIC10 / PIC12 / PIC16 / PIC18 MCUs

  @Description
    This header file provides APIs for driver for .
    Generation Information :
        Product Revision  :  PIC10 / PIC12 / PIC16 / PIC18 MCUs - 1.81.5
        Device            :  PIC18F45K22
        Driver Version    :  2.11
    The generated drivers are tested against the following:
        Compiler          :  XC8 2.20 and above
        MPLAB 	          :  MPLAB X 5.40	
*/

/*
    (c) 2018 Microchip Technology Inc. and its subsidiaries. 
    
    Subject to your compliance with these terms, you may use Microchip software and any 
    derivatives exclusively with Microchip products. It is your responsibility to comply with third party 
    license terms applicable to your use of third party software (including open source software) that 
    may accompany Microchip software.
    
    THIS SOFTWARE IS SUPPLIED BY MICROCHIP "AS IS". NO WARRANTIES, WHETHER 
    EXPRESS, IMPLIED OR STATUTORY, APPLY TO THIS SOFTWARE, INCLUDING ANY 
    IMPLIED WARRANTIES OF NON-INFRINGEMENT, MERCHANTABILITY, AND FITNESS 
    FOR A PARTICULAR PURPOSE.
    
    IN NO EVENT WILL MICROCHIP BE LIABLE FOR ANY INDIRECT, SPECIAL, PUNITIVE, 
    INCIDENTAL OR CONSEQUENTIAL LOSS, DAMAGE, COST OR EXPENSE OF ANY KIND 
    WHATSOEVER RELATED TO THE SOFTWARE, HOWEVER CAUSED, EVEN IF MICROCHIP 
    HAS BEEN ADVISED OF THE POSSIBILITY OR THE DAMAGES ARE FORESEEABLE. TO 
    THE FULLEST EXTENT ALLOWED BY LAW, MICROCHIP'S TOTAL LIABILITY ON ALL 
    CLAIMS IN ANY WAY RELATED TO THIS SOFTWARE WILL NOT EXCEED THE AMOUNT 
    OF FEES, IF ANY, THAT YOU HAVE PAID DIRECTLY TO MICROCHIP FOR THIS 
    SOFTWARE.
*/

#ifndef PIN_MANAGER_H
#define PIN_MANAGER_H

/**
  Section: Included Files
*/

#include <xc.h>

#define INPUT   1
#define OUTPUT  0

#define HIGH    1
#define LOW     0

#define ANALOG      1
#define DIGITAL     0

#define PULL_UP_ENABLED      1
#define PULL_UP_DISABLED     0

// get/set U_BAT aliases
#define U_BAT_TRIS                 TRISAbits.TRISA0
#define U_BAT_LAT                  LATAbits.LATA0
#define U_BAT_PORT                 PORTAbits.RA0
#define U_BAT_ANS                  ANSELAbits.ANSA0
#define U_BAT_SetHigh()            do { LATAbits.LATA0 = 1; } while(0)
#define U_BAT_SetLow()             do { LATAbits.LATA0 = 0; } while(0)
#define U_BAT_Toggle()             do { LATAbits.LATA0 = ~LATAbits.LATA0; } while(0)
#define U_BAT_GetValue()           PORTAbits.RA0
#define U_BAT_SetDigitalInput()    do { TRISAbits.TRISA0 = 1; } while(0)
#define U_BAT_SetDigitalOutput()   do { TRISAbits.TRISA0 = 0; } while(0)
#define U_BAT_SetAnalogMode()      do { ANSELAbits.ANSA0 = 1; } while(0)
#define U_BAT_SetDigitalMode()     do { ANSELAbits.ANSA0 = 0; } while(0)

// get/set BUZZER aliases
#define BUZZER_TRIS                 TRISAbits.TRISA1
#define BUZZER_LAT                  LATAbits.LATA1
#define BUZZER_PORT                 PORTAbits.RA1
#define BUZZER_ANS                  ANSELAbits.ANSA1
#define BUZZER_SetHigh()            do { LATAbits.LATA1 = 1; } while(0)
#define BUZZER_SetLow()             do { LATAbits.LATA1 = 0; } while(0)
#define BUZZER_Toggle()             do { LATAbits.LATA1 = ~LATAbits.LATA1; } while(0)
#define BUZZER_GetValue()           PORTAbits.RA1
#define BUZZER_SetDigitalInput()    do { TRISAbits.TRISA1 = 1; } while(0)
#define BUZZER_SetDigitalOutput()   do { TRISAbits.TRISA1 = 0; } while(0)
#define BUZZER_SetAnalogMode()      do { ANSELAbits.ANSA1 = 1; } while(0)
#define BUZZER_SetDigitalMode()     do { ANSELAbits.ANSA1 = 0; } while(0)

// get/set ENCODER_L_A aliases
#define ENCODER_L_A_TRIS                 TRISAbits.TRISA2
#define ENCODER_L_A_LAT                  LATAbits.LATA2
#define ENCODER_L_A_PORT                 PORTAbits.RA2
#define ENCODER_L_A_ANS                  ANSELAbits.ANSA2
#define ENCODER_L_A_SetHigh()            do { LATAbits.LATA2 = 1; } while(0)
#define ENCODER_L_A_SetLow()             do { LATAbits.LATA2 = 0; } while(0)
#define ENCODER_L_A_Toggle()             do { LATAbits.LATA2 = ~LATAbits.LATA2; } while(0)
#define ENCODER_L_A_GetValue()           PORTAbits.RA2
#define ENCODER_L_A_SetDigitalInput()    do { TRISAbits.TRISA2 = 1; } while(0)
#define ENCODER_L_A_SetDigitalOutput()   do { TRISAbits.TRISA2 = 0; } while(0)
#define ENCODER_L_A_SetAnalogMode()      do { ANSELAbits.ANSA2 = 1; } while(0)
#define ENCODER_L_A_SetDigitalMode()     do { ANSELAbits.ANSA2 = 0; } while(0)

// get/set ENCODER_L_B aliases
#define ENCODER_L_B_TRIS                 TRISAbits.TRISA3
#define ENCODER_L_B_LAT                  LATAbits.LATA3
#define ENCODER_L_B_PORT                 PORTAbits.RA3
#define ENCODER_L_B_ANS                  ANSELAbits.ANSA3
#define ENCODER_L_B_SetHigh()            do { LATAbits.LATA3 = 1; } while(0)
#define ENCODER_L_B_SetLow()             do { LATAbits.LATA3 = 0; } while(0)
#define ENCODER_L_B_Toggle()             do { LATAbits.LATA3 = ~LATAbits.LATA3; } while(0)
#define ENCODER_L_B_GetValue()           PORTAbits.RA3
#define ENCODER_L_B_SetDigitalInput()    do { TRISAbits.TRISA3 = 1; } while(0)
#define ENCODER_L_B_SetDigitalOutput()   do { TRISAbits.TRISA3 = 0; } while(0)
#define ENCODER_L_B_SetAnalogMode()      do { ANSELAbits.ANSA3 = 1; } while(0)
#define ENCODER_L_B_SetDigitalMode()     do { ANSELAbits.ANSA3 = 0; } while(0)

// get/set ENCODER_R_A aliases
#define ENCODER_R_A_TRIS                 TRISBbits.TRISB0
#define ENCODER_R_A_LAT                  LATBbits.LATB0
#define ENCODER_R_A_PORT                 PORTBbits.RB0
#define ENCODER_R_A_WPU                  WPUBbits.WPUB0
#define ENCODER_R_A_ANS                  ANSELBbits.ANSB0
#define ENCODER_R_A_SetHigh()            do { LATBbits.LATB0 = 1; } while(0)
#define ENCODER_R_A_SetLow()             do { LATBbits.LATB0 = 0; } while(0)
#define ENCODER_R_A_Toggle()             do { LATBbits.LATB0 = ~LATBbits.LATB0; } while(0)
#define ENCODER_R_A_GetValue()           PORTBbits.RB0
#define ENCODER_R_A_SetDigitalInput()    do { TRISBbits.TRISB0 = 1; } while(0)
#define ENCODER_R_A_SetDigitalOutput()   do { TRISBbits.TRISB0 = 0; } while(0)
#define ENCODER_R_A_SetPullup()          do { WPUBbits.WPUB0 = 1; } while(0)
#define ENCODER_R_A_ResetPullup()        do { WPUBbits.WPUB0 = 0; } while(0)
#define ENCODER_R_A_SetAnalogMode()      do { ANSELBbits.ANSB0 = 1; } while(0)
#define ENCODER_R_A_SetDigitalMode()     do { ANSELBbits.ANSB0 = 0; } while(0)

// get/set ENCODER_R_B aliases
#define ENCODER_R_B_TRIS                 TRISBbits.TRISB1
#define ENCODER_R_B_LAT                  LATBbits.LATB1
#define ENCODER_R_B_PORT                 PORTBbits.RB1
#define ENCODER_R_B_WPU                  WPUBbits.WPUB1
#define ENCODER_R_B_ANS                  ANSELBbits.ANSB1
#define ENCODER_R_B_SetHigh()            do { LATBbits.LATB1 = 1; } while(0)
#define ENCODER_R_B_SetLow()             do { LATBbits.LATB1 = 0; } while(0)
#define ENCODER_R_B_Toggle()             do { LATBbits.LATB1 = ~LATBbits.LATB1; } while(0)
#define ENCODER_R_B_GetValue()           PORTBbits.RB1
#define ENCODER_R_B_SetDigitalInput()    do { TRISBbits.TRISB1 = 1; } while(0)
#define ENCODER_R_B_SetDigitalOutput()   do { TRISBbits.TRISB1 = 0; } while(0)
#define ENCODER_R_B_SetPullup()          do { WPUBbits.WPUB1 = 1; } while(0)
#define ENCODER_R_B_ResetPullup()        do { WPUBbits.WPUB1 = 0; } while(0)
#define ENCODER_R_B_SetAnalogMode()      do { ANSELBbits.ANSB1 = 1; } while(0)
#define ENCODER_R_B_SetDigitalMode()     do { ANSELBbits.ANSB1 = 0; } while(0)

// get/set ULTRA_TRIG aliases
#define ULTRA_TRIG_TRIS                 TRISBbits.TRISB4
#define ULTRA_TRIG_LAT                  LATBbits.LATB4
#define ULTRA_TRIG_PORT                 PORTBbits.RB4
#define ULTRA_TRIG_WPU                  WPUBbits.WPUB4
#define ULTRA_TRIG_ANS                  ANSELBbits.ANSB4
#define ULTRA_TRIG_SetHigh()            do { LATBbits.LATB4 = 1; } while(0)
#define ULTRA_TRIG_SetLow()             do { LATBbits.LATB4 = 0; } while(0)
#define ULTRA_TRIG_Toggle()             do { LATBbits.LATB4 = ~LATBbits.LATB4; } while(0)
#define ULTRA_TRIG_GetValue()           PORTBbits.RB4
#define ULTRA_TRIG_SetDigitalInput()    do { TRISBbits.TRISB4 = 1; } while(0)
#define ULTRA_TRIG_SetDigitalOutput()   do { TRISBbits.TRISB4 = 0; } while(0)
#define ULTRA_TRIG_SetPullup()          do { WPUBbits.WPUB4 = 1; } while(0)
#define ULTRA_TRIG_ResetPullup()        do { WPUBbits.WPUB4 = 0; } while(0)
#define ULTRA_TRIG_SetAnalogMode()      do { ANSELBbits.ANSB4 = 1; } while(0)
#define ULTRA_TRIG_SetDigitalMode()     do { ANSELBbits.ANSB4 = 0; } while(0)

// get/set ULTRA_ECHO aliases
#define ULTRA_ECHO_TRIS                 TRISBbits.TRISB5
#define ULTRA_ECHO_LAT                  LATBbits.LATB5
#define ULTRA_ECHO_PORT                 PORTBbits.RB5
#define ULTRA_ECHO_WPU                  WPUBbits.WPUB5
#define ULTRA_ECHO_ANS                  ANSELBbits.ANSB5
#define ULTRA_ECHO_SetHigh()            do { LATBbits.LATB5 = 1; } while(0)
#define ULTRA_ECHO_SetLow()             do { LATBbits.LATB5 = 0; } while(0)
#define ULTRA_ECHO_Toggle()             do { LATBbits.LATB5 = ~LATBbits.LATB5; } while(0)
#define ULTRA_ECHO_GetValue()           PORTBbits.RB5
#define ULTRA_ECHO_SetDigitalInput()    do { TRISBbits.TRISB5 = 1; } while(0)
#define ULTRA_ECHO_SetDigitalOutput()   do { TRISBbits.TRISB5 = 0; } while(0)
#define ULTRA_ECHO_SetPullup()          do { WPUBbits.WPUB5 = 1; } while(0)
#define ULTRA_ECHO_ResetPullup()        do { WPUBbits.WPUB5 = 0; } while(0)
#define ULTRA_ECHO_SetAnalogMode()      do { ANSELBbits.ANSB5 = 1; } while(0)
#define ULTRA_ECHO_SetDigitalMode()     do { ANSELBbits.ANSB5 = 0; } while(0)

// get/set LED_1 aliases
#define LED_1_TRIS                 TRISCbits.TRISC0
#define LED_1_LAT                  LATCbits.LATC0
#define LED_1_PORT                 PORTCbits.RC0
#define LED_1_SetHigh()            do { LATCbits.LATC0 = 1; } while(0)
#define LED_1_SetLow()             do { LATCbits.LATC0 = 0; } while(0)
#define LED_1_Toggle()             do { LATCbits.LATC0 = ~LATCbits.LATC0; } while(0)
#define LED_1_GetValue()           PORTCbits.RC0
#define LED_1_SetDigitalInput()    do { TRISCbits.TRISC0 = 1; } while(0)
#define LED_1_SetDigitalOutput()   do { TRISCbits.TRISC0 = 0; } while(0)

// get/set LED_2 aliases
#define LED_2_TRIS                 TRISCbits.TRISC1
#define LED_2_LAT                  LATCbits.LATC1
#define LED_2_PORT                 PORTCbits.RC1
#define LED_2_SetHigh()            do { LATCbits.LATC1 = 1; } while(0)
#define LED_2_SetLow()             do { LATCbits.LATC1 = 0; } while(0)
#define LED_2_Toggle()             do { LATCbits.LATC1 = ~LATCbits.LATC1; } while(0)
#define LED_2_GetValue()           PORTCbits.RC1
#define LED_2_SetDigitalInput()    do { TRISCbits.TRISC1 = 1; } while(0)
#define LED_2_SetDigitalOutput()   do { TRISCbits.TRISC1 = 0; } while(0)

// get/set LED_3 aliases
#define LED_3_TRIS                 TRISCbits.TRISC2
#define LED_3_LAT                  LATCbits.LATC2
#define LED_3_PORT                 PORTCbits.RC2
#define LED_3_ANS                  ANSELCbits.ANSC2
#define LED_3_SetHigh()            do { LATCbits.LATC2 = 1; } while(0)
#define LED_3_SetLow()             do { LATCbits.LATC2 = 0; } while(0)
#define LED_3_Toggle()             do { LATCbits.LATC2 = ~LATCbits.LATC2; } while(0)
#define LED_3_GetValue()           PORTCbits.RC2
#define LED_3_SetDigitalInput()    do { TRISCbits.TRISC2 = 1; } while(0)
#define LED_3_SetDigitalOutput()   do { TRISCbits.TRISC2 = 0; } while(0)
#define LED_3_SetAnalogMode()      do { ANSELCbits.ANSC2 = 1; } while(0)
#define LED_3_SetDigitalMode()     do { ANSELCbits.ANSC2 = 0; } while(0)

// get/set LED_4 aliases
#define LED_4_TRIS                 TRISCbits.TRISC3
#define LED_4_LAT                  LATCbits.LATC3
#define LED_4_PORT                 PORTCbits.RC3
#define LED_4_ANS                  ANSELCbits.ANSC3
#define LED_4_SetHigh()            do { LATCbits.LATC3 = 1; } while(0)
#define LED_4_SetLow()             do { LATCbits.LATC3 = 0; } while(0)
#define LED_4_Toggle()             do { LATCbits.LATC3 = ~LATCbits.LATC3; } while(0)
#define LED_4_GetValue()           PORTCbits.RC3
#define LED_4_SetDigitalInput()    do { TRISCbits.TRISC3 = 1; } while(0)
#define LED_4_SetDigitalOutput()   do { TRISCbits.TRISC3 = 0; } while(0)
#define LED_4_SetAnalogMode()      do { ANSELCbits.ANSC3 = 1; } while(0)
#define LED_4_SetDigitalMode()     do { ANSELCbits.ANSC3 = 0; } while(0)

// get/set RC6 procedures
#define RC6_SetHigh()            do { LATCbits.LATC6 = 1; } while(0)
#define RC6_SetLow()             do { LATCbits.LATC6 = 0; } while(0)
#define RC6_Toggle()             do { LATCbits.LATC6 = ~LATCbits.LATC6; } while(0)
#define RC6_GetValue()              PORTCbits.RC6
#define RC6_SetDigitalInput()    do { TRISCbits.TRISC6 = 1; } while(0)
#define RC6_SetDigitalOutput()   do { TRISCbits.TRISC6 = 0; } while(0)
#define RC6_SetAnalogMode()         do { ANSELCbits.ANSC6 = 1; } while(0)
#define RC6_SetDigitalMode()        do { ANSELCbits.ANSC6 = 0; } while(0)

// get/set RC7 procedures
#define RC7_SetHigh()            do { LATCbits.LATC7 = 1; } while(0)
#define RC7_SetLow()             do { LATCbits.LATC7 = 0; } while(0)
#define RC7_Toggle()             do { LATCbits.LATC7 = ~LATCbits.LATC7; } while(0)
#define RC7_GetValue()              PORTCbits.RC7
#define RC7_SetDigitalInput()    do { TRISCbits.TRISC7 = 1; } while(0)
#define RC7_SetDigitalOutput()   do { TRISCbits.TRISC7 = 0; } while(0)
#define RC7_SetAnalogMode()         do { ANSELCbits.ANSC7 = 1; } while(0)
#define RC7_SetDigitalMode()        do { ANSELCbits.ANSC7 = 0; } while(0)

// get/set MOTOR_1A aliases
#define MOTOR_1A_TRIS                 TRISDbits.TRISD0
#define MOTOR_1A_LAT                  LATDbits.LATD0
#define MOTOR_1A_PORT                 PORTDbits.RD0
#define MOTOR_1A_ANS                  ANSELDbits.ANSD0
#define MOTOR_1A_SetHigh()            do { LATDbits.LATD0 = 1; } while(0)
#define MOTOR_1A_SetLow()             do { LATDbits.LATD0 = 0; } while(0)
#define MOTOR_1A_Toggle()             do { LATDbits.LATD0 = ~LATDbits.LATD0; } while(0)
#define MOTOR_1A_GetValue()           PORTDbits.RD0
#define MOTOR_1A_SetDigitalInput()    do { TRISDbits.TRISD0 = 1; } while(0)
#define MOTOR_1A_SetDigitalOutput()   do { TRISDbits.TRISD0 = 0; } while(0)
#define MOTOR_1A_SetAnalogMode()      do { ANSELDbits.ANSD0 = 1; } while(0)
#define MOTOR_1A_SetDigitalMode()     do { ANSELDbits.ANSD0 = 0; } while(0)

// get/set RD1 procedures
#define RD1_SetHigh()            do { LATDbits.LATD1 = 1; } while(0)
#define RD1_SetLow()             do { LATDbits.LATD1 = 0; } while(0)
#define RD1_Toggle()             do { LATDbits.LATD1 = ~LATDbits.LATD1; } while(0)
#define RD1_GetValue()              PORTDbits.RD1
#define RD1_SetDigitalInput()    do { TRISDbits.TRISD1 = 1; } while(0)
#define RD1_SetDigitalOutput()   do { TRISDbits.TRISD1 = 0; } while(0)
#define RD1_SetAnalogMode()         do { ANSELDbits.ANSD1 = 1; } while(0)
#define RD1_SetDigitalMode()        do { ANSELDbits.ANSD1 = 0; } while(0)

// get/set MOTOR_2A aliases
#define MOTOR_2A_TRIS                 TRISDbits.TRISD2
#define MOTOR_2A_LAT                  LATDbits.LATD2
#define MOTOR_2A_PORT                 PORTDbits.RD2
#define MOTOR_2A_ANS                  ANSELDbits.ANSD2
#define MOTOR_2A_SetHigh()            do { LATDbits.LATD2 = 1; } while(0)
#define MOTOR_2A_SetLow()             do { LATDbits.LATD2 = 0; } while(0)
#define MOTOR_2A_Toggle()             do { LATDbits.LATD2 = ~LATDbits.LATD2; } while(0)
#define MOTOR_2A_GetValue()           PORTDbits.RD2
#define MOTOR_2A_SetDigitalInput()    do { TRISDbits.TRISD2 = 1; } while(0)
#define MOTOR_2A_SetDigitalOutput()   do { TRISDbits.TRISD2 = 0; } while(0)
#define MOTOR_2A_SetAnalogMode()      do { ANSELDbits.ANSD2 = 1; } while(0)
#define MOTOR_2A_SetDigitalMode()     do { ANSELDbits.ANSD2 = 0; } while(0)

// get/set MOTOR_3A aliases
#define MOTOR_3A_TRIS                 TRISDbits.TRISD3
#define MOTOR_3A_LAT                  LATDbits.LATD3
#define MOTOR_3A_PORT                 PORTDbits.RD3
#define MOTOR_3A_ANS                  ANSELDbits.ANSD3
#define MOTOR_3A_SetHigh()            do { LATDbits.LATD3 = 1; } while(0)
#define MOTOR_3A_SetLow()             do { LATDbits.LATD3 = 0; } while(0)
#define MOTOR_3A_Toggle()             do { LATDbits.LATD3 = ~LATDbits.LATD3; } while(0)
#define MOTOR_3A_GetValue()           PORTDbits.RD3
#define MOTOR_3A_SetDigitalInput()    do { TRISDbits.TRISD3 = 1; } while(0)
#define MOTOR_3A_SetDigitalOutput()   do { TRISDbits.TRISD3 = 0; } while(0)
#define MOTOR_3A_SetAnalogMode()      do { ANSELDbits.ANSD3 = 1; } while(0)
#define MOTOR_3A_SetDigitalMode()     do { ANSELDbits.ANSD3 = 0; } while(0)

// get/set MOTOR_4A aliases
#define MOTOR_4A_TRIS                 TRISDbits.TRISD4
#define MOTOR_4A_LAT                  LATDbits.LATD4
#define MOTOR_4A_PORT                 PORTDbits.RD4
#define MOTOR_4A_ANS                  ANSELDbits.ANSD4
#define MOTOR_4A_SetHigh()            do { LATDbits.LATD4 = 1; } while(0)
#define MOTOR_4A_SetLow()             do { LATDbits.LATD4 = 0; } while(0)
#define MOTOR_4A_Toggle()             do { LATDbits.LATD4 = ~LATDbits.LATD4; } while(0)
#define MOTOR_4A_GetValue()           PORTDbits.RD4
#define MOTOR_4A_SetDigitalInput()    do { TRISDbits.TRISD4 = 1; } while(0)
#define MOTOR_4A_SetDigitalOutput()   do { TRISDbits.TRISD4 = 0; } while(0)
#define MOTOR_4A_SetAnalogMode()      do { ANSELDbits.ANSD4 = 1; } while(0)
#define MOTOR_4A_SetDigitalMode()     do { ANSELDbits.ANSD4 = 0; } while(0)

// get/set BT_STATE_PIN aliases
#define BT_STATE_PIN_TRIS                 TRISDbits.TRISD6
#define BT_STATE_PIN_LAT                  LATDbits.LATD6
#define BT_STATE_PIN_PORT                 PORTDbits.RD6
#define BT_STATE_PIN_ANS                  ANSELDbits.ANSD6
#define BT_STATE_PIN_SetHigh()            do { LATDbits.LATD6 = 1; } while(0)
#define BT_STATE_PIN_SetLow()             do { LATDbits.LATD6 = 0; } while(0)
#define BT_STATE_PIN_Toggle()             do { LATDbits.LATD6 = ~LATDbits.LATD6; } while(0)
#define BT_STATE_PIN_GetValue()           PORTDbits.RD6
#define BT_STATE_PIN_SetDigitalInput()    do { TRISDbits.TRISD6 = 1; } while(0)
#define BT_STATE_PIN_SetDigitalOutput()   do { TRISDbits.TRISD6 = 0; } while(0)
#define BT_STATE_PIN_SetAnalogMode()      do { ANSELDbits.ANSD6 = 1; } while(0)
#define BT_STATE_PIN_SetDigitalMode()     do { ANSELDbits.ANSD6 = 0; } while(0)

// get/set RE2 procedures
#define RE2_SetHigh()            do { LATEbits.LATE2 = 1; } while(0)
#define RE2_SetLow()             do { LATEbits.LATE2 = 0; } while(0)
#define RE2_Toggle()             do { LATEbits.LATE2 = ~LATEbits.LATE2; } while(0)
#define RE2_GetValue()              PORTEbits.RE2
#define RE2_SetDigitalInput()    do { TRISEbits.TRISE2 = 1; } while(0)
#define RE2_SetDigitalOutput()   do { TRISEbits.TRISE2 = 0; } while(0)
#define RE2_SetAnalogMode()         do { ANSELEbits.ANSE2 = 1; } while(0)
#define RE2_SetDigitalMode()        do { ANSELEbits.ANSE2 = 0; } while(0)

/**
   @Param
    none
   @Returns
    none
   @Description
    GPIO and peripheral I/O initialization
   @Example
    PIN_MANAGER_Initialize();
 */
void PIN_MANAGER_Initialize (void);

/**
 * @Param
    none
 * @Returns
    none
 * @Description
    Interrupt on Change Handling routine
 * @Example
    PIN_MANAGER_IOC();
 */
void PIN_MANAGER_IOC(void);



#endif // PIN_MANAGER_H
/**
 End of File
*/