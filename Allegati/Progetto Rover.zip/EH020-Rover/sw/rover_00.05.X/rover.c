// File: rover.c
// Author: Mattia Bassi


////////////////////////////////////////////////////////////////////////////////
// application includes
#include "rover.h"
#include "mcc_generated_files/mcc.h"


////////////////////////////////////////////////////////////////////////////////
// system includes
#include <stdbool.h>
#include <string.h>  // needed by memset
#include <stdint.h>



////////////////////////////////////////////////////////////////////////////////
// constants
#define SOUND_SPEED_MS 300 // m/s

////////////////////////////////////////////////////////////////////////////////
// typedefs


typedef struct {   
    uint16_t start_time;
    uint16_t stop_time;
    uint16_t delta_time;
    uint32_t distance_cm;
    uint32_t distance_cm_prec;
    bool meausure_is_ended;
    distance_meausure_state_e meausure_state;
    
} us_sensor_t;

typedef struct {   
    uint16_t tone_frequency;
    uint16_t tone_duration;
    bool     tone_is_active;
    uint32_t tone_toggle_count;
    
    uint32_t timer_reload_value;
    uint32_t tone_events_count;
    uint32_t tone_half_period_us;
} sound_t;

typedef struct {
    us_sensor_t us_sensor;
    sound_t sound;
    
} rover_data_t;

////////////////////////////////////////////////////////////////////////////////
// macros





////////////////////////////////////////////////////////////////////////////////
// static variables
static volatile rover_data_t rover_data;



////////////////////////////////////////////////////////////////////////////////
// private functions


////////////////////////////////////////////////////////////////////////////////
// public functions


//------------------------------------------------------------------------------
uint32_t EUSART1_parseUint()
//------------------------------------------------------------------------------
{
	char c;
    uint32_t num = 0;
    
    uint16_t cycle = 0;
    
    // igniore non numeric char
    do {
        c = EUSART1_Read();
        cycle++;
        if (cycle >= 3) return 0;
    } while (!(c >= '0' && c <= '9'));
    
    cycle = 0;
    
    do {
        num = num * 10 + c - '0';
        c = EUSART1_Read();
        
    }while ((c >= '0' && c <= '9'));
    
    return num;
}


//------------------------------------------------------------------------------
void EUSART1_write_str(char *str)
//------------------------------------------------------------------------------
{
	int i;
	
	// check pointers
	if (str == NULL) {
		return;
	}
	
	// write to EUSART1
	for (i = 0; i < strlen(str); i++) {
		EUSART1_Write(str[i]);
	}
}

//------------------------------------------------------------------------------
bool bluetooth_module_is_connected()
//------------------------------------------------------------------------------
{
	return BT_STATE_PIN_GetValue();
}

//------------------------------------------------------------------------------
void pwm_motors_right(uint16_t duty_value)
//------------------------------------------------------------------------------
{
	PWM4_LoadDutyValue(duty_value);
}

//------------------------------------------------------------------------------
void pwm_motors_left(uint16_t duty_value)
//------------------------------------------------------------------------------
{
	PWM5_LoadDutyValue(duty_value);
}

//------------------------------------------------------------------------------
void tone(uint32_t frequency, uint32_t duration)
//------------------------------------------------------------------------------
{  
    
    
    // active sound generation
    rover_data.sound.tone_is_active = true;

    //data.sound.tone_half_period_us = (1000000 / (frequency * 2));
    //data.sound.timer_reload_value = 65535 - (data.sound.tone_half_period_us / 16);

    rover_data.sound.timer_reload_value = 65536 - (31250/frequency);

    TMR0_WriteTimer(rover_data.sound.timer_reload_value);

    rover_data.sound.tone_toggle_count = (2 * frequency * duration) / 1000;

    //printf("rv %u, tog %u\n", data.sound.timer_reload_value, data.sound.tone_toggle_count);

    BUZZER_SetLow();
    TMR0_StartTimer();

    // wait end of sound generation
    while(rover_data.sound.tone_is_active == true) {
        // none, wait
    }
    BUZZER_SetLow();
    
}

//------------------------------------------------------------------------------
void set_motors(motors_selection_e motors, motors_direction_e direction)
//------------------------------------------------------------------------------
{
	switch(motors) {
        case MOTORS_R: {
            if (direction == MOTORS_FORWARDS) {
                MOTOR_1A_SetHigh();
                MOTOR_2A_SetLow(); 
            } else {
            
                if (direction == MOTORS_BACKWARDS) {
                    MOTOR_1A_SetLow();
                    MOTOR_2A_SetHigh();
                } else {

                    if (direction == MOTORS_STOP) {
                        MOTOR_1A_SetLow();
                        MOTOR_2A_SetLow();
                    }
                }
            }
            break;
        }
        
        case MOTORS_L: {
            if (direction == MOTORS_FORWARDS) {
                MOTOR_3A_SetHigh();
                MOTOR_4A_SetLow(); 
            } else {
            
                if (direction == MOTORS_BACKWARDS) {
                    MOTOR_3A_SetLow();
                    MOTOR_4A_SetHigh();
                } else {

                    if (direction == MOTORS_STOP) {
                        MOTOR_3A_SetLow();
                        MOTOR_4A_SetLow();
                    }
                }
            }
            break;
        }
        
        default: {
            // none
            break;
        }
    }
}

//------------------------------------------------------------------------------
inline uint32_t get_uBat()
//------------------------------------------------------------------------------
{
    uint32_t adc_value = 0;
    
    ADC_SelectChannel(U_BAT);
    ADC_StartConversion();
    while(!ADC_IsConversionDone());
    adc_value = ADC_GetConversionResult();
    
    //data.battery.uBat_v = ((5 * adc_value * (R7_VALUE + R6_VALUE)) / (1023 * R7_VALUE)) ;
    //data.battery.uBat_mv = (((5000 * adc_value * (R7_VALUE + R6_VALUE)) / (1023 * R7_VALUE)) );
    return (uint32_t)(((5000 * adc_value * 2.446) / (1023)) );
    
}




//------------------------------------------------------------------------------
inline void ultrasonic_sensor_start_meausure()
//------------------------------------------------------------------------------
{
    rover_data.us_sensor.meausure_is_ended = false;

    TMR1_Reload();
    rover_data.us_sensor.start_time = TMR1_ReadTimer();
    TMR1_StartTimer();

    //enable TMR1 singlepulse mode
    TMR1_StartSinglePulseAcquisition();

    // generate trigger signal of 5us
    ULTRA_TRIG_SetLow();
    ULTRA_TRIG_SetHigh();
    DELAY_microseconds(5);
    ULTRA_TRIG_SetLow();
}

//------------------------------------------------------------------------------
inline uint8_t get_ultrasonic_sensor_meausure_state()
//------------------------------------------------------------------------------
{
    return rover_data.us_sensor.meausure_state;
}

//------------------------------------------------------------------------------
inline uint8_t get_distance_cm()
//------------------------------------------------------------------------------
{
    return rover_data.us_sensor.distance_cm;
}

void tmr0_event() {
    static uint32_t events_counter = 0;
    
    //LED_2_Toggle();
     
    if (rover_data.sound.tone_is_active == true) {
        if (events_counter <= rover_data.sound.tone_toggle_count) {
            BUZZER_Toggle();
            TMR0_WriteTimer(rover_data.sound.timer_reload_value);
            // increment values
            events_counter++;
        } else {
            TMR0_StopTimer();
            BUZZER_SetLow();
            events_counter = 0;

            // stop sound generation
            rover_data.sound.tone_is_active = false;
        }
    }

}

void tmr1_event() {
    // timer elapsed
    // problem with pulse of ultrasonic distance sensor
    // pulse timeout
    // stop timer
    //data.us_sensor.distance_cm = 200;
    rover_data.us_sensor.meausure_is_ended = true;
    rover_data.us_sensor.meausure_state = MEAUSURE_OUT_OF_RANGE;
    TMR1_StopTimer();
}


void tmr1_gate_event() {
    // pulse of ultrasonic distance sensor terminated
    
    // stop timer
    TMR1_StopTimer();
    
    // read current timer value
    rover_data.us_sensor.stop_time = TMR1_ReadTimer();
    // calculate delta time
    rover_data.us_sensor.delta_time = rover_data.us_sensor.stop_time -  rover_data.us_sensor.start_time;
    // calculate distance in cm
    // 
    rover_data.us_sensor.distance_cm = (3 * rover_data.us_sensor.delta_time) / 400;
    rover_data.us_sensor.meausure_is_ended = true;
    rover_data.us_sensor.meausure_state = MEAUSURE_DONE;
}



//------------------------------------------------------------------------------
inline void tone_init()
//------------------------------------------------------------------------------
{
    // stop timer0
    TMR0_StopTimer();
    // reload timer0
    TMR0_Reload();
    
    // register callbacks
    TMR0_SetInterruptHandler(tmr0_event);
    
    BUZZER_SetLow();
}


//------------------------------------------------------------------------------
inline void ultrasonic_sensor_init()
//------------------------------------------------------------------------------
{  
    // stop timer1
    TMR1_StopTimer();
    // reload timer1
    TMR1_Reload();
    
    TMR1_SetGateInterruptHandler(tmr1_gate_event);
    TMR1_SetInterruptHandler(tmr1_event);

    // init value
    rover_data.us_sensor.delta_time  = 0;
    rover_data.us_sensor.distance_cm = 0;
    rover_data.us_sensor.start_time  = 0;
    rover_data.us_sensor.stop_time   = 0;    
}