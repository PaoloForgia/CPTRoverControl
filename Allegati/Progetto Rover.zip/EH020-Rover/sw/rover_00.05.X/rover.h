// File: rover.h
// Author: Mattia Bassi

#ifndef __ROVER_H__
#define	__ROVER_H__



////////////////////////////////////////////////////////////////////////////////
// application includes



////////////////////////////////////////////////////////////////////////////////
// system includes
#include <stdbool.h>
#include <string.h>
#include <stdio.h>
#include <math.h>


////////////////////////////////////////////////////////////////////////////////
// features

//#ifdef FEAT_
//    #define FEAT_
//#endif



////////////////////////////////////////////////////////////////////////////////
// constants




////////////////////////////////////////////////////////////////////////////////
// typedefs

typedef enum {
	R7_VALUE = 47, // k ohms
    R6_VALUE = 68, // k ohms
            
	// reserved value
	RESISTORS_MAX
} resistors_e;

typedef enum {
	MEAUSURE_OUT_OF_RANGE,
	MEAUSURE_DONE, 
    MEAUSURE_IN_PROGRESS, 
            
	// reserved value
	MEAUSURE_MAX
} distance_meausure_state_e;

typedef enum {
	MOTORS_L,
	MOTORS_R, 
            
	// reserved value
	MOTORS_SELECTION_MAX
} motors_selection_e;

typedef enum {
	BT_MODULE_NOT_CONNECTED = 0x00,
    BT_MODULE_CONNECTED = 0x01, 
            
	// reserved value
	BT_MODULE_MAX
} bluetooth_e;

typedef enum {
    MOTORS_FORWARDS,
    MOTORS_BACKWARDS,
    MOTORS_STOP,  
            
	// reserved value
	MOTORS_DIRECTIONS_MAX
} motors_direction_e;


////////////////////////////////////////////////////////////////////////////////
// private functions
void tmr0_event();
void tmr1_event();
void tmr1_gate_event();

////////////////////////////////////////////////////////////////////////////////
// public functions

inline void tone_init();

uint32_t EUSART1_parseUint();
void EUSART1_write_str(char *str);

bool bluetooth_module_is_connected();

void pwm_motors_right(uint16_t duty_value);
void pwm_motors_left(uint16_t duty_value);

void tone(uint32_t frequency, uint32_t duration);

void set_motors(motors_selection_e motors, motors_direction_e direction);

inline uint32_t get_uBat();

inline void ultrasonic_sensor_init();
inline void ultrasonic_sensor_start_meausure();
inline uint8_t get_ultrasonic_sensor_meausure_state();
inline uint8_t get_distance_cm();



#endif	// __ROVER_H__


